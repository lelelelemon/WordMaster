package Model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class IO {
	// read all the word in to an arraylist of Word
	ArrayList<Word> readFirst(String filename){
		return null;
	
	}
	//  we can read from each correspoding file  such as 1.txt => wordlist A
	WordList read(String filename) {

		return null;
	}

	// write correesponding record to files such as wordlist A => 1.txt( 1.txt is the name we specific for each Word)
	String writeWordList(WordList wordList){
		/* offset size right recite
		 * english chinese right total
		 * english chinese right total		
		 */
		return null;
	}
}
